#!/bin/bash

#qsub options
#$ -N trimmomatic
#$ -r y
#$ -V
#$ -j y
#$ -pe threaded 2

module load trimmomatic/0.36

#Tag script variables
TRIMMOMATIC_JAR="/cm/shared/apps/trimmomatic/0.36/trimmomatic-0.36.jar"
TRIMMOMATIC_PE_ADAPTORS="/cm/shared/apps/trimmomatic/0.36/adapters/TruSeq3-PE.fa"
TRIMMOMATIC_SE_ADAPTORS="/cm/shared/apps/trimmomatic/0.36/adapters/TruSeq3-SE.fa"
CLEAN_FASTQ_PATH=${1}
SAMPLE=${2}
FASTQ_PATH=${3}

if [ -f ${FASTQ_PATH}${SAMPLE}_R2.fastq.gz ]
then
    java -jar ${TRIMMOMATIC_JAR} \
    PE -phred33 -threads 2 \
    ${FASTQ_PATH}${SAMPLE}_R1.fastq.gz ${FASTQ_PATH}${SAMPLE}_R2.fastq.gz \
    ${CLEAN_FASTQ_PATH}${SAMPLE}_R1.fastq.gz ${CLEAN_FASTQ_PATH}${SAMPLE}_R1_UNPAIRED.fastq.gz \
    ${CLEAN_FASTQ_PATH}${SAMPLE}_R2.fastq.gz ${CLEAN_FASTQ_PATH}${SAMPLE}_R2_UNPAIRED.fastq.gz \
    ILLUMINACLIP:${TRIMMOMATIC_PE_ADAPTORS}:2:30:10 LEADING:3 TRAILING:3 SLIDINGWINDOW:4:15 MINLEN:36
    rm ${CLEAN_FASTQ_PATH}${SAMPLE}_R1_UNPAIRED.fastq.gz ${CLEAN_FASTQ_PATH}${SAMPLE}_R2_UNPAIRED.fastq.gz
else
    java -jar ${TRIMMOMATIC_JAR} \
    SE -phred33 -threads 2 \
    ${FASTQ_PATH}${SAMPLE}_R1.fastq.gz \
    ${CLEAN_FASTQ_PATH}${SAMPLE}_R1.fastq.gz \
    ILLUMINACLIP:${TRIMMOMATIC_SE_ADAPTORS}:2:30:10 LEADING:3 TRAILING:3 SLIDINGWINDOW:4:15 MINLEN:36
fi

echo "FASTQ files ${SAMPLE} cleaned"

#Delete tag
rm ${CLEAN_FASTQ_PATH}wait_tag_${SAMPLE} 