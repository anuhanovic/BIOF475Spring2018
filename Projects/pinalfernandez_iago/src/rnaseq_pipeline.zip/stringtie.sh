#!/bin/bash

#qsub options
#$ -N stringtie
#$ -r y
#$ -V
#$ -j y
#$ -pe threaded 2

module load stringtie/1.3.3

#Tag script variables
STRINGTIE_PATH=${1}
SAMPLE=${2}
ALIGNED_HISAT_PATH=${3}
GENES_GTF=${4}

#Stringtie
mkdir ${STRINGTIE_PATH}${SAMPLE}

stringtie -e -B -p 2 -G ${GENES_GTF} -o ${STRINGTIE_PATH}${SAMPLE}/${SAMPLE}.gtf -A ${STRINGTIE_PATH}${SAMPLE}/${SAMPLE}.tab ${ALIGNED_HISAT_PATH}${SAMPLE}/${SAMPLE}.bam

#Delete temporary files and tag
rm ${STRINGTIE_PATH}wait_tag_${SAMPLE}