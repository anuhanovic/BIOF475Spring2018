#!/bin/bash

#qsub options
#$ -N tuxedo
#$ -pe threaded 1
#$ -o ./p_RNA_muscle_biopsies/output_tuxedo_pipeline.log
#$ -M iagopf@yahoo.es
#$ -m eas
#$ -r y
#$ -V
#$ -j y

## Analysis of RNAseq muscle biopsies. All the FASTQ files have been demultiplexed and stored into the FASTQ folder

#DATA TO MODIFY
SAMPLE_SIMPLIFIED_NAME="p_RNA_muscle_biopsies"
REFERENCE="reference_genome/homo_sapiens/UCSC/hg19/"

#FILE LOCALIZATION
PROJECT_FOLDER="${HOME}/${SAMPLE_SIMPLIFIED_NAME}/"
FASTQ_PATH="${PROJECT_FOLDER}FASTQ/"
CLEAN_FASTQ_PATH="${PROJECT_FOLDER}CLEAN_FASTQ/"
QC_PATH="${PROJECT_FOLDER}QC/"
ALIGNED_TOPHAT_PATH="${PROJECT_FOLDER}ALIGNED_TOPHAT/"
CUFFLINKS_PATH="${PROJECT_FOLDER}CUFFLINKS/"
CUFFNORM_PATH="${PROJECT_FOLDER}CUFFNORM/"
SORTED_BAM="${PROJECT_FOLDER}SORTED_BAM/"
MACS_PATH="${PROJECT_FOLDER}MACS/"
CUFFMERGE_SCRIPT="${HOME}/tools/cuffmerge"
CUFFQUANT_PATH="${PROJECT_FOLDER}CUFFQUANT/"
CUFFNORM_PATH="${PROJECT_FOLDER}CUFFNORM/"
CUFFDIFF_PATH="${PROJECT_FOLDER}CUFFDIFF/"
ALIGNCOMPARE_PATH="${HOME}/tools/aligncompare.py"
ALIGNED_HISAT_PATH="${PROJECT_FOLDER}ALIGNED_HISAT/"
STRINGTIE_PATH="${PROJECT_FOLDER}STRINGTIE/"

#Genome variables
GENES_GTF="${HOME}/${REFERENCE}Annotation/Genes/genes.gtf"
GENOME="${HOME}/${REFERENCE}Sequence/WholeGenomeFasta/genome.fa"
BOWTIE2INDEX_PATH="${HOME}/${REFERENCE}Sequence/Bowtie2Index/"
HISAT_INDEX="${HOME}/${REFERENCE}Sequence/HisatIndex/genome"
HISAT_SPLICESITES="${HOME}/${REFERENCE}Sequence/HisatIndex/splicesites.txt"

#####################################################

#Fix sample names and renew sample list
SAMPLES=""

for i in $FASTQ_PATH*; do
    mv ${i} ${i/_001.fastq.gz/.fastq.gz}
    mv ${i} ${i/_S*_R1.fastq.gz/_R1.fastq.gz}
    mv ${i} ${i/_S*_R2.fastq.gz/_R2.fastq.gz}
    mv ${i} ${i/-/_}
done

for i in $FASTQ_PATH*; do
    SAMPLES="${SAMPLES} $(basename $i)"
done

SAMPLES=${SAMPLES//_R1.fastq.gz/}
SAMPLES=${SAMPLES//_R2.fastq.gz/}
SAMPLES=$(echo -e "${SAMPLES// /\\n}" | sort -u)

echo "Fixed sample names and renewed sample list"

#####################################################

#Use trimmomatic to do initial quality control
mkdir ${CLEAN_FASTQ_PATH}

mkdir -p ${CLEAN_FASTQ_PATH}logs

for i in $SAMPLES; do
    if [ ! -f ${CLEAN_FASTQ_PATH}${i}_R1.fastq.gz ]; then
        touch ${CLEAN_FASTQ_PATH}wait_tag_${i}
        qsub ${PROJECT_FOLDER}trimmomatic.sh ${CLEAN_FASTQ_PATH} ${i} ${FASTQ_PATH}
    fi
done

while [[ $(ls ${CLEAN_FASTQ_PATH}wait_tag_* -A) ]]; do
  sleep 2
done

echo "Cleaned fastq files"

#####################################################

#Tophat aligned to transcriptome of hg19 (Align RNA-seq) in both single end and paired end experiments
#Index .bam files
mkdir ${ALIGNED_TOPHAT_PATH}

for i in $SAMPLES; do
    if [ ! -d ${ALIGNED_TOPHAT_PATH}${i} ]; then
        touch ${ALIGNED_TOPHAT_PATH}wait_tag_${i}
        qsub ${PROJECT_FOLDER}tophat.sh ${ALIGNED_TOPHAT_PATH} ${i} ${CLEAN_FASTQ_PATH} ${GENES_GTF} ${BOWTIE2INDEX_PATH}genome
    fi
done

while [[ $(ls ${ALIGNED_TOPHAT_PATH}wait_tag_* -A) ]]; do
  sleep 2
done

echo "Aligned and indexed samples"

#####################################################

#Quality control
mkdir ${QC_PATH}

for i in $SAMPLES; do
    if [ ! -f ${QC_PATH}${i}.html ]; then
        touch ${QC_PATH}wait_tag_${i}
        qsub ${PROJECT_FOLDER}fastqc.sh ${QC_PATH} ${i} ${ALIGNED_TOPHAT_PATH}
    fi 
done

while [[ $(ls ${QC_PATH}wait_tag_* -A) ]]; do
  sleep 2
done

echo "Finished quality control"

#####################################################

#Assemble transcripts with Cufflinks
mkdir ${CUFFLINKS_PATH}

for i in $SAMPLES; do
    if [ ! -d ${CUFFLINKS_PATH}${i} ]; then
        echo "Running Cufflinks sample: $i"
        touch ${CUFFLINKS_PATH}wait_tag_${i}
        qsub ${PROJECT_FOLDER}cufflinks.sh ${CUFFLINKS_PATH} ${i} ${SAMPLE_THREADS} ${ALIGNED_TOPHAT_PATH} ${GENES_GTF} 
    fi
done

while [[ $(ls ${CUFFLINKS_PATH}wait_tag_* -A) ]]; do
  sleep 2
done

echo "Finished Cufflinks"

#####################################################
'''
#Merge transcript file with Cuffmerge
if [ -f ${CUFFLINKS_PATH}assemblies.txt ] ; then
    rm ${CUFFLINKS_PATH}assemblies.txt
fi

for i in $SAMPLES; do
    echo "${CUFFLINKS_PATH}${i}/transcripts.gtf" >> ${CUFFLINKS_PATH}assemblies.txt
done

if [ ! -f ${CUFFLINKS_PATH}merged_gtf.gtf ]; then
    echo "Generating merged gtf"
    touch ${CUFFLINKS_PATH}wait_tag_cuffmerge
    qsub ${PROJECT_FOLDER}cuffmerge.sh ${CUFFMERGE_SCRIPT} ${CUFFLINKS_PATH} ${GENES_GTF} ${GENOME}
fi

while [[ $(ls ${CUFFLINKS_PATH}wait_tag_cuffmerge) ]]; do
  sleep 2
done
'''
#####################################################

#Cuffquant
mkdir ${CUFFQUANT_PATH}

for i in $SAMPLES; do
    if [ ! -f ${CUFFQUANT_PATH}${i}/abundances.cxb ]; then
        echo "Running Cuffquant sample: $i"
        touch ${CUFFQUANT_PATH}wait_tag_${i}
        qsub ${PROJECT_FOLDER}cuffquant.sh ${ALIGNED_TOPHAT_PATH} ${GENES_GTF} ${i} ${CUFFQUANT_PATH} 
    fi
done

while [[ $(ls ${CUFFQUANT_PATH}wait_tag_* -A) ]]; do
  sleep 2
done

#####################################################

#Cuffnorm myoblast-myotube
mkdir ${CUFFNORM_PATH}MYOBLAST_MYOTUBE -p

SAMPLE_PATH_LIST=()
SAMPLE_LIST=()

for i in $SAMPLES; do
    if [[ $i == *"HSMM"* ]]; then
        SAMPLE_PATH_LIST+=(${CUFFQUANT_PATH}${i}'/abundances.cxb')
        SAMPLE_LIST+=(${i})
    fi
done

if [ ! -f ${CUFFNORM_PATH}MYOBLAST_MYOTUBE/genes.fpkm_table ]; then
    qsub ${PROJECT_FOLDER}cuffnorm.sh ${CUFFNORM_PATH}MYOBLAST_MYOTUBE "$(echo ${SAMPLE_PATH_LIST[@]})" "$(echo ${SAMPLE_LIST[@]} | tr ' ' ,)" ${GENES_GTF}
fi

#####################################################

#Cuffnorm human muscle biopsies
mkdir ${CUFFNORM_PATH}MUSCLE_BIOPSIES -p

SAMPLE_PATH_LIST=()
SAMPLE_LIST=()

for i in $SAMPLES; do
    case $i in 
        *NT*|*IBM*|*HMGCR*|*SRP*|*Jo1*|*PL7*|*PL12*|*Mi2*|*NXP2*|*TIF1*|*MDA5*)
        SAMPLE_PATH_LIST+=(${CUFFQUANT_PATH}${i}"/abundances.cxb")
        SAMPLE_LIST+=(${i})
    esac
done

if [ ! -f ${CUFFNORM_PATH}MUSCLE_BIOPSIES/genes.fpkm_table ]; then
    qsub ${PROJECT_FOLDER}cuffnorm.sh ${CUFFNORM_PATH}MUSCLE_BIOPSIES "$(echo ${SAMPLE_PATH_LIST[@]})" "$(echo ${SAMPLE_LIST[@]} | tr ' ' ,)" ${GENES_GTF}
fi

#####################################################

#Cuffdiff to generate differential expression
mkdir ${CUFFDIFF_PATH}

NT=()
NO_IBM_MYOSITIS=()
IBM=()
IMNM=()
ASS=()
DM=()
HMGCR=()
SRP=()
JO1=()
PL7=()
PL12=()
MI2=()
NXP2=()
TIF1=()
MDA5=()
HSMM_D0=()
HSMM_D1=()
HSMM_D2=()
HSMM_D3=()
HSMM_D4=()
HSMM_D5=()
HSMM_D6=()

wait

for i in $SAMPLES; do
    case $i in
        *NT*)
            NT+=(${CUFFQUANT_PATH}${i}"/abundances.cxb")
        ;;&
        *HMGCR*|*SRP*|*Jo1*|*PL7*|*PL12*|*Mi2*|*NXP2*|*TIF1*|*MDA5*)
            NO_IBM_MYOSITIS+=(${CUFFQUANT_PATH}${i}"/abundances.cxb")
        ;;&
        *IBM*) 
            IBM+=(${CUFFQUANT_PATH}${i}"/abundances.cxb")
        ;;&
        *HMGCR*|*SRP*)
            IMNM+=(${CUFFQUANT_PATH}${i}"/abundances.cxb")
        ;;&
        *Jo1*|*PL7*|*PL12*)
            ASS+=(${CUFFQUANT_PATH}${i}"/abundances.cxb")
        ;;&
        *Mi2*|*NXP2*|*TIF1*|*MDA5*)
            DM+=(${CUFFQUANT_PATH}${i}"/abundances.cxb")
        ;;&
        *HMGCR*) 
            HMGCR+=(${CUFFQUANT_PATH}${i}"/abundances.cxb")
        ;;&
        *SRP*) 
            SRP+=(${CUFFQUANT_PATH}${i}"/abundances.cxb")
        ;;&
        *Jo1*) 
            JO1+=(${CUFFQUANT_PATH}${i}"/abundances.cxb")
        ;;&
        *PL7*) 
            PL7+=(${CUFFQUANT_PATH}${i}"/abundances.cxb")
        ;;&
        *PL12*) 
            PL12+=(${CUFFQUANT_PATH}${i}"/abundances.cxb")
        ;;&
        *Mi2*) 
            MI2+=(${CUFFQUANT_PATH}${i}"/abundances.cxb")
        ;;&
        *NXP2*) 
            NXP2+=(${CUFFQUANT_PATH}${i}"/abundances.cxb")
        ;;&
        *TIF1*) 
            TIF1+=(${CUFFQUANT_PATH}${i}"/abundances.cxb")
        ;;&
        *MDA5*) 
            MDA5+=(${CUFFQUANT_PATH}${i}"/abundances.cxb")
        ;;&
        *HSMM_D0*) 
            HSMM_D0+=(${CUFFQUANT_PATH}${i}"/abundances.cxb")
        ;;&
        *HSMM_D1*) 
            HSMM_D1+=(${CUFFQUANT_PATH}${i}"/abundances.cxb")
        ;;&
        *HSMM_D2*) 
            HSMM_D2+=(${CUFFQUANT_PATH}${i}"/abundances.cxb")
        ;;&
        *HSMM_D3*) 
            HSMM_D3+=(${CUFFQUANT_PATH}${i}"/abundances.cxb")
        ;;&
        *HSMM_D4*) 
            HSMM_D4+=(${CUFFQUANT_PATH}${i}"/abundances.cxb")
        ;;&
        *HSMM_D5*) 
            HSMM_D5+=(${CUFFQUANT_PATH}${i}"/abundances.cxb")
        ;;&
        *HSMM_D6*) 
            HSMM_D6+=(${CUFFQUANT_PATH}${i}"/abundances.cxb")
        ;;
    esac
done

IBM_VS_NON_IBM=$(echo $( echo ${NT[@]} | tr ' ' ,) \
                      $( echo ${IBM[@]} | tr ' ' ,) \
                      $( echo ${NO_IBM_MYOSITIS[@]} | tr ' ' ,))

IBM_VS_NON_IBM_LABELS="NT,IBM,NO_IBM_MYOSITIS"

SYNDROMES=$(echo $( echo ${NT[@]} | tr ' ' ,) \
                 $( echo ${IBM[@]} | tr ' ' ,) \
                 $( echo ${IMNM[@]} | tr ' ' ,) \
                 $( echo ${ASS[@]} | tr ' ' ,) \
                 $( echo ${DM[@]} | tr ' ' ,))

SYNDROME_LABELS="NT,IBM,IMNM,ASS,DM"

ANTIBODIES=$(echo $( echo ${NT[@]} | tr ' ' ,) \
                  $( echo ${IBM[@]} | tr ' ' ,) \
                  $( echo ${HMGCR[@]} | tr ' ' ,) \
                  $( echo ${SRP[@]} | tr ' ' ,) \
                  $( echo ${JO1[@]} | tr ' ' ,) \
                  $( echo ${PL7[@]} | tr ' ' ,) \
                  $( echo ${PL12[@]} | tr ' ' ,) \
                  $( echo ${MI2[@]} | tr ' ' ,) \
                  $( echo ${NXP2[@]} | tr ' ' ,) \
                  $( echo ${TIF1[@]} | tr ' ' ,) \
                  $( echo ${MDA5[@]} | tr ' ' ,))

ANTIBODY_LABELS="NT,IBM,HMGCR,SRP,JO1,PL7,PL12,MI2,NXP2,TIF1,MDA5"

MYOBLAST_MYOTUBE=$(echo $( echo ${HSMM_D0[@]} | tr ' ' ,) \
                        $( echo ${HSMM_D1[@]} | tr ' ' ,) \
                        $( echo ${HSMM_D2[@]} | tr ' ' ,) \
                        $( echo ${HSMM_D3[@]} | tr ' ' ,) \
                        $( echo ${HSMM_D4[@]} | tr ' ' ,) \
                        $( echo ${HSMM_D5[@]} | tr ' ' ,) \
                        $( echo ${HSMM_D6[@]} | tr ' ' ,))

MYOBLAST_MYOTUBE_LABELS="HSMM_D0,HSMM_D1,HSMM_D2,HSMM_D3,HSMM_D4,HSMM_D5,HSMM_D6"

#IBM vs non_IBM
if [ ! -f ${CUFFDIFF_PATH}IBM_VS_NON_IBM/gene_exp.diff ]; then
qsub ${PROJECT_FOLDER}cuffdiff.sh ${CUFFDIFF_PATH}IBM_VS_NON_IBM "$(echo ${IBM_VS_NON_IBM})" ${IBM_VS_NON_IBM_LABELS} ${GENES_GTF} ${GENOME}
fi

#CLINICAL SYNDROME COMPARISON
if [ ! -f ${CUFFDIFF_PATH}SYNDROMES/gene_exp.diff ]; then
qsub ${PROJECT_FOLDER}cuffdiff.sh ${CUFFDIFF_PATH}SYNDROMES "$(echo ${SYNDROMES})" ${SYNDROME_LABELS} ${GENES_GTF} ${GENOME}
fi

#AUTOANTIBODY COMPARISON
if [ ! -f ${CUFFDIFF_PATH}AUTOANTIBODIES/gene_exp.diff ]; then
qsub ${PROJECT_FOLDER}cuffdiff.sh ${CUFFDIFF_PATH}AUTOANTIBODIES "$(echo ${ANTIBODIES})" ${ANTIBODY_LABELS} ${GENES_GTF} ${GENOME}
fi

#MYOBLAST-MYOTUBE COMPARISON
if [ ! -f ${CUFFDIFF_PATH}MYOBLAST_MYOTUBE/gene_exp.diff ]; then
qsub ${PROJECT_FOLDER}cuffdiff.sh ${CUFFDIFF_PATH}MYOBLAST_MYOTUBE "$(echo ${MYOBLAST_MYOTUBE})" ${MYOBLAST_MYOTUBE_LABELS} ${GENES_GTF} ${GENOME}
fi

#####################################################
'''
#Delete lines with TCONS_ or XLOC_ from cuffdiff
for file in gene_exp isoform_exp ; do
    for dir in ${CUFFDIFF_PATH}*/ ; do
        for str_pattern in TCONS_ XLOC_ ; do
            grep -v "${str_pattern}" ${dir}${file}.diff > ${dir}${file}2.diff
            mv ${dir}${file}2.diff ${dir}${file}.diff
            echo "Dropping ${str_pattern} from ${dir}"
        done
    done
done

#Delete lines with TCONS_ or XLOC_ from cufflinks
for file in genes.fpkm_tracking isoforms.fpkm_tracking ; do
    for dir in ${CUFFLINKS_PATH}*/ ; do
        for str_pattern in TCONS_ XLOC_ ; do
            grep -v "${str_pattern}" ${dir}${file} > ${dir}${file}2
            mv ${dir}${file}2 ${dir}${file}
            echo "Dropping ${str_pattern} from ${dir}"
        done
    done
done

echo "Eliminated TCONS and XLOC genes"
'''