#!/bin/bash

#qsub options
#$ -N star
#$ -r y
#$ -V
#$ -j y
#$ -pe threaded 20

module load star/2.5
module load samtools/1.4.1

#Tag script variables
ALIGNED_STAR_PATH=${1}
SAMPLE=${2}
FASTQ_PATH=${3}
STAR_INDEX=${4}

#Alignment using STAR
mkdir ${ALIGNED_STAR_PATH}${SAMPLE}

if [ -f ${FASTQ_PATH}${SAMPLE}_R2.fastq.gz ]
then
    STAR \
    --runThreadN 20 \
    --readFilesCommand zcat \
    --genomeDir $STAR_INDEX \
    --readFilesIn ${FASTQ_PATH}${SAMPLE}_R1.fastq.gz ${FASTQ_PATH}${SAMPLE}_R2.fastq.gz \
    --outFileNamePrefix ${ALIGNED_STAR_PATH}${SAMPLE}/${SAMPLE}
    echo "${SAMPLE} is paired-end"
else
    STAR \
    --runThreadN 20 \
    --readFilesCommand zcat \
    --genomeDir $STAR_INDEX \
    --readFilesIn ${FASTQ_PATH}${SAMPLE}_R1.fastq.gz \
    --outFileNamePrefix ${ALIGNED_STAR_PATH}${SAMPLE}/${SAMPLE}
    echo "${SAMPLE} is single-end"
fi

#Convert sam to bam
samtools view -@ 20 -b -o ${ALIGNED_STAR_PATH}${SAMPLE}/${SAMPLE}Aligned.out.bam ${ALIGNED_STAR_PATH}${SAMPLE}/${SAMPLE}Aligned.out.sam

#Sort bam
samtools sort -@ 20 -o ${ALIGNED_STAR_PATH}${SAMPLE}/${SAMPLE}.bam ${ALIGNED_STAR_PATH}${SAMPLE}/${SAMPLE}Aligned.out.bam

#Index bam file
samtools index ${ALIGNED_STAR_PATH}${SAMPLE}/${SAMPLE}.bam

#Delete temporary files and tag
rm ${ALIGNED_STAR_PATH}${SAMPLE}/${SAMPLE}Aligned.out.bam ${ALIGNED_STAR_PATH}${SAMPLE}/${SAMPLE}Aligned.out.sam ${ALIGNED_STAR_PATH}wait_tag_${SAMPLE}