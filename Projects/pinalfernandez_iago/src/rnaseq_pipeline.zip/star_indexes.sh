#!/bin/bash

#qsub options
#$ -N star
#$ -o ./reference_genome/STAR_indexes.log
#$ -r y
#$ -V
#$ -j y
#$ -pe threaded 16

module load star/2.5

#Human STAR indexes
HUMAN_REFERENCE="reference_genome/homo_sapiens/UCSC/hg19/"

HUMAN_GENES_GTF="${HOME}/${HUMAN_REFERENCE}Annotation/Genes/genes.gtf"
HUMAN_GENOME="${HOME}/${HUMAN_REFERENCE}Sequence/WholeGenomeFasta/genome.fa"
HUMAN_STAR_INDEX="${HOME}/${HUMAN_REFERENCE}Sequence/STARIndex"

mkdir $HUMAN_STAR_INDEX

STAR \
--runThreadN 8 \
--runMode genomeGenerate \
--genomeDir $HUMAN_STAR_INDEX \
--genomeFastaFiles $HUMAN_GENOME \
--sjdbGTFfile $HUMAN_GENES_GTF&

#Mouse STAR indexes
MOUSE_REFERENCE="reference_genome/mus_musculus/UCSC/mm10/"

MOUSE_GENES_GTF="${HOME}/${MOUSE_REFERENCE}Annotation/Genes/genes.gtf"
MOUSE_GENOME="${HOME}/${MOUSE_REFERENCE}Sequence/WholeGenomeFasta/genome.fa"
MOUSE_STAR_INDEX="${HOME}/${MOUSE_REFERENCE}Sequence/STARIndex"

mkdir $MOUSE_STAR_INDEX

STAR \
--runThreadN 8 \
--runMode genomeGenerate \
--genomeDir $MOUSE_STAR_INDEX \
--genomeFastaFiles $MOUSE_GENOME \
--sjdbGTFfile $MOUSE_GENES_GTF&

wait