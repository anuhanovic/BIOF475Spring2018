#!/bin/bash

#qsub options
#$ -N cuffmerge
#$ -o ./p_RNA_muscle_biopsies/output_tuxedo_pipeline.log
#$ -r y
#$ -V
#$ -j y
#$ -pe threaded 10

module load cufflinks/2.2.1

#Tag script variables
CUFFMERGE_SCRIPT=${1}
CUFFLINKS_PATH=${2}
GENES_GTF=${3}
GENOME=${4}

${CUFFMERGE_SCRIPT} -o ${CUFFLINKS_PATH}merged_gtf -g ${GENES_GTF} -s ${GENOME} -p 10 ${CUFFLINKS_PATH}assemblies.txt

#Delete tag
rm ${CUFFLINKS_PATH}wait_tag_cuffmerge