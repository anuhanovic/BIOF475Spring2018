#!/bin/bash

#$ -N cuffdiff
#$ -o ./p_RNA_muscle_biopsies/output_tuxedo_pipeline.log
#$ -r y
#$ -V
#$ -j y
#$ -pe threaded 10

module load cufflinks/2.2.1

CUFFDIFF_PATH=${1}
PATH_LIST=( "${2}" )
LABEL_LIST=${3}
GENES_GTF=${4}
GENOME=${5}

cuffdiff \
    --no-update-check \
    --max-bundle-frags 1000000000000 \
    -p 10 \
    --library-type fr-firststrand \
    -o ${CUFFDIFF_PATH} \
    -u ${GENES_GTF} \
    -b ${GENOME} \
    -L ${LABEL_LIST} \
    ${PATH_LIST}