#!/bin/bash

#qsub options
#$ -N cuffnorm
#$ -o ./p_RNA_muscle_biopsies/output_tuxedo_pipeline.log
#$ -r y
#$ -V
#$ -j y
#$ -pe threaded 10

module load cufflinks/2.2.1

#Tag script variables
CUFFNORM_PATH=${1}
PATH_LIST=( "${2}" )
LABEL_LIST=( "${3}" )
GENES_GTF=${4}

echo $PATH_LIST
echo $LABEL_LIST

cuffnorm --no-update-check -p 10 -o ${CUFFNORM_PATH} --library-type fr-firststrand -L ${LABEL_LIST} ${GENES_GTF} ${PATH_LIST}