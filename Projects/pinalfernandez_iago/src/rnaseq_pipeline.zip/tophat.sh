#!/bin/bash

#qsub options
#$ -N tophat
#$ -o ./p_RNA_muscle_biopsies/output_tuxedo_pipeline.log
#$ -r y
#$ -V
#$ -j y
#$ -pe threaded 2

module load tophat/2.0.14
module load bowtie2/2.2.4
module load samtools/1.4.1

#Tag script variables
ALIGNED_TOPHAT_PATH=${1}
SAMPLE=${2}
MERGED_FASTQ_PATH=${3}
GENES_GTF=${4}
GENOME=${5}

if [ -f ${MERGED_FASTQ_PATH}${SAMPLE}_R2.fastq.gz ]
then
    tophat2 \
    -p 2 \
    -G ${GENES_GTF} \
    -o ${ALIGNED_TOPHAT_PATH}${SAMPLE} \
    --library-type fr-firststrand \
    -a 10 \
    --no-novel-juncs \
    --b2-sensitive \
    ${GENOME} \
    ${MERGED_FASTQ_PATH}${SAMPLE}_R1.fastq.gz \
    ${MERGED_FASTQ_PATH}${SAMPLE}_R2.fastq.gz
    echo "${2} is paired-end"
else
    tophat2 \
    -p 2 \
    -G ${GENES_GTF} \
    -o ${ALIGNED_TOPHAT_PATH}${SAMPLE} \
    --library-type fr-firststrand \
    -a 10 \
    --no-novel-juncs \
    --b2-sensitive \
    ${GENOME} \
    ${MERGED_FASTQ_PATH}${SAMPLE}_R1.fastq.gz
    echo "${2} is single-end"
fi
wait

samtools index -@ 2 ${ALIGNED_TOPHAT_PATH}${SAMPLE}/accepted_hits.bam
echo "BAM files ${SAMPLE} aligned"

#Delete tag
rm ${ALIGNED_TOPHAT_PATH}wait_tag_${SAMPLE} 