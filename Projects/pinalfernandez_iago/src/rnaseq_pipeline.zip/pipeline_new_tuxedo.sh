#!/bin/bash

#qsub options
#$ -N new_tuxedo
#$ -pe threaded 1
#$ -o ./p_RNA_muscle_biopsies/output_new_tuxedo_pipeline.log
#$ -M iagopf@yahoo.es
#$ -m eas
#$ -r y
#$ -V
#$ -j y

## Analysis of RNAseq muscle biopsies. All the FASTQ files have been demultiplexed and stored into the FASTQ folder

#DATA TO MODIFY
SAMPLE_SIMPLIFIED_NAME="p_RNA_muscle_biopsies"
REFERENCE="reference_genome/homo_sapiens/UCSC/hg19/"

#FILE LOCALIZATION
PROJECT_FOLDER="${HOME}/${SAMPLE_SIMPLIFIED_NAME}/"
FASTQ_PATH="${PROJECT_FOLDER}FASTQ/"
CLEAN_FASTQ_PATH="${PROJECT_FOLDER}CLEAN_FASTQ/"
QC_PATH="${PROJECT_FOLDER}QC/"
ALIGNED_TOPHAT_PATH="${PROJECT_FOLDER}ALIGNED_TOPHAT/"
CUFFLINKS_PATH="${PROJECT_FOLDER}CUFFLINKS/"
CUFFNORM_PATH="${PROJECT_FOLDER}CUFFNORM/"
SORTED_BAM="${PROJECT_FOLDER}SORTED_BAM/"
MACS_PATH="${PROJECT_FOLDER}MACS/"
CUFFMERGE_SCRIPT="${HOME}/tools/cuffmerge"
CUFFQUANT_PATH="${PROJECT_FOLDER}CUFFQUANT/"
CUFFNORM_PATH="${PROJECT_FOLDER}CUFFNORM/"
CUFFDIFF_PATH="${PROJECT_FOLDER}CUFFDIFF/"
ALIGNCOMPARE_PATH="${HOME}/tools/aligncompare.py"
ALIGNED_STAR_PATH="${PROJECT_FOLDER}ALIGNED_STAR/"
STRINGTIE_STAR_PATH="${PROJECT_FOLDER}STRINGTIE/"
PREPDE_PATH="${HOME}/tools/prepDE.py"

#Genome variables
GENES_GTF="${HOME}/${REFERENCE}Annotation/Genes/genes.gtf"
GENOME="${HOME}/${REFERENCE}Sequence/WholeGenomeFasta/genome.fa"
BOWTIE2INDEX_PATH="${HOME}/${REFERENCE}Sequence/Bowtie2Index/"
HISAT_INDEX="${HOME}/${REFERENCE}Sequence/HisatIndex/genome"
HISAT_SPLICESITES="${HOME}/${REFERENCE}Sequence/HisatIndex/splicesites.txt"
STAR_INDEX="${HOME}/${REFERENCE}Sequence/STARIndex/"

#####################################################

#Fix sample names and renew sample list
SAMPLES=""

for i in $FASTQ_PATH*; do
    mv ${i} ${i/_001.fastq.gz/.fastq.gz}
    mv ${i} ${i/_S*_R1.fastq.gz/_R1.fastq.gz}
    mv ${i} ${i/_S*_R2.fastq.gz/_R2.fastq.gz}
    mv ${i} ${i/-/_}
done

for i in $FASTQ_PATH*; do
    SAMPLES="${SAMPLES} $(basename $i)"
done

SAMPLES=${SAMPLES//_R1.fastq.gz/}
SAMPLES=${SAMPLES//_R2.fastq.gz/}
SAMPLES=$(echo -e "${SAMPLES// /\\n}" | sort -u)

echo "Fixed sample names and renewed sample list"

#####################################################

#Use trimmomatic to do initial quality control
mkdir -p ${CLEAN_FASTQ_PATH}logs

for SAMPLE in $SAMPLES; do
    if [ ! -f ${CLEAN_FASTQ_PATH}${SAMPLE}_R1.fastq.gz ]; then
        touch ${CLEAN_FASTQ_PATH}wait_tag_${SAMPLE}
        qsub -o ${CLEAN_FASTQ_PATH}logs/${SAMPLE}.txt ${PROJECT_FOLDER}trimmomatic.sh ${CLEAN_FASTQ_PATH} ${SAMPLE} ${FASTQ_PATH}
    fi
done

while [[ $(ls ${CLEAN_FASTQ_PATH}wait_tag_* -A) ]]; do
  sleep 2
done

echo "Cleaned fastq files"

#####################################################

#STAR aligned to transcriptome of hg19 (Align RNA-seq) in both single end and paired end experiments
mkdir -p ${ALIGNED_STAR_PATH}logs

for SAMPLE in $SAMPLES; do
    if [ ! -d ${ALIGNED_STAR_PATH}${SAMPLE} ]; then
        touch ${ALIGNED_STAR_PATH}wait_tag_${SAMPLE}
        qsub -o ${ALIGNED_STAR_PATH}logs/${SAMPLE}.txt ${PROJECT_FOLDER}star.sh ${ALIGNED_STAR_PATH} ${SAMPLE} ${CLEAN_FASTQ_PATH} ${STAR_INDEX}
    fi
done

while [[ $(ls ${ALIGNED_STAR_PATH}wait_tag_* -A) ]]; do
  sleep 2
done

echo "Aligned and indexed samples"

#####################################################

#Quality control
mkdir -p ${QC_PATH}logs

for SAMPLE in $SAMPLES; do
    if [ ! -f ${QC_PATH}${SAMPLE}.html ]; then
        touch ${QC_PATH}wait_tag_${SAMPLE}
        qsub -o ${QC_PATH}logs/${SAMPLE}.txt ${PROJECT_FOLDER}fastqc.sh ${QC_PATH} ${SAMPLE} ${ALIGNED_STAR_PATH}
    fi 
done

while [[ $(ls ${QC_PATH}wait_tag_* -A) ]]; do
  sleep 2
done

echo "Finished quality control"

#####################################################

#Stringtie from STAR
mkdir -p ${STRINGTIE_STAR_PATH}logs

for SAMPLE in $SAMPLES; do
    if [ ! -d ${STRINGTIE_STAR_PATH}${SAMPLE} ]; then
        touch ${STRINGTIE_STAR_PATH}wait_tag_${SAMPLE}
        qsub -o ${STRINGTIE_STAR_PATH}logs/${SAMPLE}.txt ${PROJECT_FOLDER}stringtie.sh ${STRINGTIE_STAR_PATH} ${SAMPLE} ${ALIGNED_STAR_PATH} ${GENES_GTF}
    fi
done

while [[ $(ls ${STRINGTIE_STAR_PATH}wait_tag_* -A) ]]; do
  sleep 2
done

#Run prepde
python ${PREPDE_PATH} -i ${STRINGTIE_STAR_PATH} -g ${STRINGTIE_STAR_PATH}gene_counts.csv -t ${STRINGTIE_STAR_PATH}transcript_counts.csv

#####################################################

echo "Aligned and indexed samples"