#!/usr/bin/env python3

'''
1.0.0 Iago Pinal-Fernandez 18oct2016
	Module to compare the RNA expression of two conditions:
	It requires:
		Python 3
		Cufflinks 2
	-First parameter: Output folder
	-Second parameter: Input folder
	-Third parameter: Genome path
	-Fourth parameter: GTF path
	-Fifth parameter: Number of threads per sample
	-Sixth parameter: Name features of group 1 to compare
	-Seventh parameter: Name features of group 2 to compare

	Example: python test.py ${OUTPUT} SAMPLES ${GENOME} ${GENES_GTF} 1 IBM NT
	Expected output: Comparing 9 IBM with 11 NT

	Example: python test.py ${OUTPUT} SAMPLES ${GENOME} ${GENES_GTF} 1 IBM NT
	Expected output: Comparing 9 IBM with the rest(22)
'''

#Modules
import sys
import os

#Variables
output_folder = sys.argv[1]
input_folder = sys.argv[2]
genome_path = sys.argv[3]
gtf_path = sys.argv[4]
sample_threads = sys.argv[5]
group1_features = sys.argv[6].split()
try:
	group2_features = sys.argv[7].split()
	print(group2_features)
except:
	group2_features = None

def aligncompare(output_folder, input_folder, genome_path, gtf_path, sample_threads, group1_features, group2_features):
	group1 = ''
	group2 = ''

	if group2_features == None:
		experiment_output_dir = output_folder + '_'.join(group1_features) + '_vs_All' 
		os.system('mkdir ' + experiment_output_dir)
		for filename in os.listdir(input_folder):
			if all(x in filename for x in group1_features):
				if group1 == '':
					group1 = input_folder + filename + "/accepted_hits.bam"
				else:
					group1 = group1 + "," + input_folder + filename + "/accepted_hits.bam"
			else:
				if group2 == '':
					group2 = input_folder + filename + "/accepted_hits.bam"
				else:
					group2 = group2 + "," + input_folder + filename + "/accepted_hits.bam"
		print("Comparing {} {} with the rest ({})".format(len(group1.split(',')), '_'.join(group1_features), len(group2.split(','))))
		cuffdiff_command = 'cuffdiff --no-update-check --max-bundle-frags 1000000000000 -p {} -o {} -b {} --library-type fr-firststrand -L All,{} -u {} {} {}'.format(sample_threads, experiment_output_dir, genome_path, '_'.join(group1_features), gtf_path, group2, group1)
		os.system(cuffdiff_command)
	else:
		experiment_output_dir = output_folder + '_'.join(group1_features) + '_vs_' +  '_'.join(group2_features)
		os.system('mkdir ' + experiment_output_dir)
		for filename in os.listdir(input_folder):
			if all(x in filename for x in group1_features):
				if group1 == '':
					group1 = input_folder + filename + "/accepted_hits.bam"
				else:
					group1 = group1 + "," + input_folder + filename + "/accepted_hits.bam"
			elif all(x in filename for x in group2_features):
				if group2 == '':
					group2 = input_folder + filename + "/accepted_hits.bam"
				else:
					group2 = group2 + "," + input_folder + filename + "/accepted_hits.bam"
		print("Comparing {} {} with {} {}".format(len(group1.split(',')), '_'.join(group1_features), len(group2.split(',')), '_'.join(group2_features)))
		cuffdiff_command = 'cuffdiff --no-update-check --max-bundle-frags 1000000000000 -p {} -o {} -b {} --library-type fr-firststrand -L {},{} -u {} {} {}'.format(sample_threads, experiment_output_dir, genome_path, '_'.join(group2_features), '_'.join(group1_features), gtf_path, group2, group1)
		os.system(cuffdiff_command)

aligncompare(output_folder, input_folder, genome_path, gtf_path, sample_threads, group1_features, group2_features)