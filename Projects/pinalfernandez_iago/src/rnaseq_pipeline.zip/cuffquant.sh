#!/bin/bash

#qsub options
#$ -N cuffquant
#$ -o ./p_RNA_muscle_biopsies/output_tuxedo_pipeline.log
#$ -r y
#$ -V
#$ -j y
#$ -pe threaded 2

module load cufflinks/2.2.1

#Tag script variables
ALIGNED_TOPHAT_PATH=${1}
GENES_GTF=${2}
SAMPLE=${3}
CUFFQUANT_PATH=${4}

cuffquant \
    --no-update-check \
    ${GENES_GTF} \
    -p 2 \
    -o ${CUFFQUANT_PATH}${SAMPLE} \
    ${ALIGNED_TOPHAT_PATH}${SAMPLE}/accepted_hits.bam

#Delete tag
rm ${CUFFQUANT_PATH}wait_tag_${SAMPLE} 