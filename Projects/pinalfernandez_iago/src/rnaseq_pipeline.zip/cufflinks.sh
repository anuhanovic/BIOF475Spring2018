#!/bin/bash

#qsub options
#$ -N cufflinks
#$ -o ./p_RNA_muscle_biopsies/output_tuxedo_pipeline.log
#$ -r y
#$ -V
#$ -j y
#$ -pe threaded 2

module load cufflinks/2.2.1

#Tag script variables
CUFFLINKS_PATH=${1}
SAMPLE=${2}
ALIGNED_TOPHAT_PATH=${3}
GENES_GTF=${4}

cufflinks \
    --no-update-check \
    --max-bundle-frags 1000000000000 \
    -G ${GENES_GTF} \
    -p 2 \
    -o ${CUFFLINKS_PATH}${SAMPLE} \
    --library-type fr-firststrand \
    ${ALIGNED_TOPHAT_PATH}${SAMPLE}/accepted_hits.bam

#Delete tag
rm ${CUFFLINKS_PATH}wait_tag_${SAMPLE} 