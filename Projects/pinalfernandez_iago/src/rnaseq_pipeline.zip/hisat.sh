#!/bin/bash

#qsub options
#$ -N hisat
#$ -r y
#$ -V
#$ -j y
#$ -pe threaded 2

module load hisat2/2.1.0
module load samtools/1.4.1

#Tag script variables
ALIGNED_HISAT_PATH=${1}
SAMPLE=${2}
FASTQ_PATH=${3}
HISAT_INDEX=${4}
HISAT_SPLICESITES=${5}

#Generate splicesite file
# module load python/3.4.6
# GENES_GTF="${HOME}/reference_genome/homo_sapiens/UCSC/hg19/Annotation/Genes/genes.gtf"
# python /cm/shared/apps/hisat2/2.0.4/extract_splice_sites.py ${GENES_GTF} > splicesites.txt

#Alignment using HISAT2
mkdir ${ALIGNED_HISAT_PATH}${SAMPLE}

if [ -f ${FASTQ_PATH}${SAMPLE}_R2.fastq.gz ]
then
    hisat2 \
    -p 2 \
    -x ${HISAT_INDEX} \
    --known-splicesite-infile ${HISAT_SPLICESITES} \
    -1 ${FASTQ_PATH}${SAMPLE}_R1.fastq.gz \
    -2 ${FASTQ_PATH}${SAMPLE}_R2.fastq.gz \
    -S ${ALIGNED_HISAT_PATH}${SAMPLE}/${SAMPLE}.sam
    echo "${SAMPLE} is paired-end"
else
    hisat2 \
    -p 2 \
    -x ${HISAT_INDEX} \
    --known-splicesite-infile ${HISAT_SPLICESITES} \
    -U ${FASTQ_PATH}${SAMPLE}_R1.fastq.gz \
    -S ${ALIGNED_HISAT_PATH}${SAMPLE}/${SAMPLE}.sam
    echo "${SAMPLE} is single-end"
fi

#Convert sam to bam
samtools view -@ 2 -b -o ${ALIGNED_HISAT_PATH}${SAMPLE}/${SAMPLE}_unsorted.bam ${ALIGNED_HISAT_PATH}${SAMPLE}/${SAMPLE}.sam

#Sort bam
samtools sort -@ 2 -o ${ALIGNED_HISAT_PATH}${SAMPLE}/${SAMPLE}.bam ${ALIGNED_HISAT_PATH}${SAMPLE}/${SAMPLE}_unsorted.bam

#Index bam file
samtools index ${ALIGNED_HISAT_PATH}${SAMPLE}/${SAMPLE}.bam

#Delete temporary files and tag
rm ${ALIGNED_HISAT_PATH}wait_tag_${SAMPLE} ${ALIGNED_HISAT_PATH}${SAMPLE}/${SAMPLE}.sam ${ALIGNED_HISAT_PATH}${SAMPLE}/${SAMPLE}_unsorted.bam