#!/bin/bash

#qsub options
#$ -N fastqc
#$ -r y
#$ -V
#$ -j y

module load oracle/java/jre1.8.0_40
module load fastqc/0.11.2

#Tag script variables
QC_PATH=${1}
SAMPLE=${2}
ALIGNED_PATH=${3}

#Run fastqc
mkdir ${QC_PATH}${SAMPLE}

fastqc ${ALIGNED_PATH}${SAMPLE}/${SAMPLE}.bam -o ${QC_PATH}${SAMPLE}

mv ${QC_PATH}${SAMPLE}/*.html ${QC_PATH}${SAMPLE}.html

rm -r ${QC_PATH}${SAMPLE}

#Delete tag
rm ${QC_PATH}wait_tag_${SAMPLE} 
